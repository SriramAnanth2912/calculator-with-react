import Calculator from "./Calculator.js";
// import History from "./History.js";
import "./App.css";

function App() {
  return <div className="body">{<Calculator />}</div>;
}

export default App;
